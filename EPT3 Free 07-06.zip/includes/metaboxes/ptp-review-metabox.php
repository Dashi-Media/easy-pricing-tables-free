<div id="dh_ptp_banner_review_box_container">
    
   <p style="text-align: center;">
        <a href="http://wordpress.org/support/view/plugin-reviews/easy-pricing-tables?filter=5" target="_blank" class="button button-primary button-large"><?php _e('Leave a review', 'easy-pricing-tables'); ?></a>
    </p>
    

</div>
