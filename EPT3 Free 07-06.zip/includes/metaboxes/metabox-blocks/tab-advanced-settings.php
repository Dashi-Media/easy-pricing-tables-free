<div id="dh_ptp_tabs_2" class="dh_ptp_tab">
    <div id="dh_ptp_design_tabs_container">
        <?php include ( PTP_PLUGIN_PATH . '/includes/metaboxes/metabox-blocks/advanced-settings/simple-flat-settings.php');?>
    </div>
</div>
