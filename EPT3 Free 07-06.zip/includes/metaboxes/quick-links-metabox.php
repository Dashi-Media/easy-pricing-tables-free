<div id="dh_ptp_banner_quick_links_container">
    
    <ul>
        <li><div class="dashicons dashicons-arrow-right"></div> <a href="http://wordpress.org/support/plugin/easy-pricing-tables" target="_blank"><?php _e( 'Problems, Suggestions? Visit the support forum.', 'easy-pricing-tables' ); ?></a> </li>
        <li><div class="dashicons dashicons-arrow-right"></div> <a href="http://wordpress.org/plugins/easy-pricing-tables/faq/" target="_blank"><?php _e( 'FAQ', 'easy-pricing-tables' ); ?></a> </li>
        <li><div class="dashicons dashicons-arrow-right"></div> <a href="http://fatcatapps.com/easypricingtables/?utm_campaign=ept-ui-sidebar&utm_source=free-plugin&utm_medium=link&utm_content=v3" target="_blank"><?php _e( 'Easy Pricing Tables Premium', 'easy-pricing-tables' ); ?></a> </li>
    </ul>
    

</div>
